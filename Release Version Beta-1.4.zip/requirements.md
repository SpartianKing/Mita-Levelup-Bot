```npm install discord.js dotenv sqlite3
```


The above command is used to install the dependencies. It cannot be ran via the file, but rather copy and paste the code.